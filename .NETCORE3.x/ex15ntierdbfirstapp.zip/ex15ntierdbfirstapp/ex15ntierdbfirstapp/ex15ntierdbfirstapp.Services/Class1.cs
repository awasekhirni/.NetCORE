﻿using System;

namespace ex15ntierdbfirstapp.Services
{
    public class Class1
    {
    }
}
