﻿using System;

namespace ex15ntierdbfirstapp.Domain
{
    public class Class1
    {
    }
}
