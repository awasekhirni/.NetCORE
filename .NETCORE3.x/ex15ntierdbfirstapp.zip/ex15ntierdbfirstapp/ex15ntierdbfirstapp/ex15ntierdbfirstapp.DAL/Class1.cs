﻿using System;

namespace ex15ntierdbfirstapp.DAL
{
    public class Class1
    {
    }
}
