﻿using System;

namespace ex15ntierdbfirstapp.Service
{
    public class Class1
    {
    }
}
