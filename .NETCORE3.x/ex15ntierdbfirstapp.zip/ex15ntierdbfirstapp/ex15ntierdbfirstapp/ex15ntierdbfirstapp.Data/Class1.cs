﻿using System;

namespace ex15ntierdbfirstapp.Data
{
    public class Class1
    {
    }
}
