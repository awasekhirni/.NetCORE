﻿using ex16cleanarchswagapisol.Domain.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Net.Http.Headers;
using System.Text;

namespace ex16cleanarchswagapisol.Infrastructure.Persistence.Context
{
    public class StoreDbContext: DbContext
    {
        public StoreDbContext(DbContextOptions options): base(options) { }

        public DbSet<Product> Products { get; set; }
    }
}
