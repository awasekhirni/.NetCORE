﻿using ex16cleanarchswagapisol.Domain.Interfaces;
using ex16cleanarchswagapisol.Domain.Models;
using ex16cleanarchswagapisol.Infrastructure.Persistence.Context;
using System;
using System.Collections.Generic;
using System.Text;

namespace ex16cleanarchswagapisol.Infrastructure.Persistence.Repositories
{
    public class ProductRepository : IProductRepository
    {

        public StoreDbContext _context;

        public ProductRepository(StoreDbContext context)
        {
            _context = context;
        }

        IEnumerable<Product> IProductRepository.GetProducts()
        {
            return _context.Products;
        }
    }
}
