﻿using ex16cleanarchswagapisol.Application.Interfaces;
using ex16cleanarchswagapisol.Application.Services;
using ex16cleanarchswagapisol.Domain.Interfaces;
using ex16cleanarchswagapisol.Infrastructure.Persistence.Repositories;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;

namespace ex16cleanarchswagapisol.Infrastructure.Ioc
{
    public class DependencyContainer
    {
        public static void RegisterServices(IServiceCollection services)
        {
            //register application layer to scopre 
            services.AddScoped<IProductService, ProductService>();
            //RegisterServices the repository
            services.AddScoped<IProductRepository, ProductRepository>();
        }

    }
}
