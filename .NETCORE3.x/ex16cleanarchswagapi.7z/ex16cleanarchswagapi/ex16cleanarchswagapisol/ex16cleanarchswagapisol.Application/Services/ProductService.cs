﻿using ex16cleanarchswagapisol.Application.Interfaces;
using ex16cleanarchswagapisol.Application.ViewModels;
using ex16cleanarchswagapisol.Application.Services;
using ex16cleanarchswagapisol.Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace ex16cleanarchswagapisol.Application.Services
{
    public class ProductService : IProductService
    {
        //repository reference
        public IProductRepository _productRepo;

        //constructor
        public ProductService(IProductRepository productRepo)
        {
            _productRepo = productRepo;
        }
        public ProductViewModel GetProducts()
        {
            return new ProductViewModel()
            {
                Products = _productRepo.GetProducts()
            };
        }

    }
}
