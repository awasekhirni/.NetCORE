﻿using ex16cleanarchswagapisol.Domain.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace ex16cleanarchswagapisol.Application.ViewModels
{
    public class ProductViewModel
    {
        public IEnumerable<Product> Products { get; set; }
    }
}
