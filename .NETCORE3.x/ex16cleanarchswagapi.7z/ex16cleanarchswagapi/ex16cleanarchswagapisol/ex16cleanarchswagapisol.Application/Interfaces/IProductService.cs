﻿using ex16cleanarchswagapisol.Application.ViewModels;
using System;
using System.Collections.Generic;
using System.Text;

namespace ex16cleanarchswagapisol.Application.Interfaces
{
    public interface IProductService
    {
        ProductViewModel GetProducts();
    }
}
