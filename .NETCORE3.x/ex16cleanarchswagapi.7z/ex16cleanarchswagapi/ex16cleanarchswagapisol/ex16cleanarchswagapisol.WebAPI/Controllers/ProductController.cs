﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ex16cleanarchswagapisol.Application.Interfaces;
using ex16cleanarchswagapisol.Application.ViewModels;
using ex16cleanarchswagapisol.Domain.Models;
using Microsoft.AspNetCore.Mvc;

namespace ex16cleanarchswagapisol.WebAPI.Controllers
{
    [Route("api/products")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        //injecting service refeence 
        private IProductService _productService;
        //constructor
        public ProductController(IProductService productService)
        {
            _productService = productService;
        }
        // GET: api/<ProductController>
        [HttpGet]
        public IEnumerable<Product> Get()
        {
            return _productService.GetProducts().Products.ToList();
        }
    }
}
