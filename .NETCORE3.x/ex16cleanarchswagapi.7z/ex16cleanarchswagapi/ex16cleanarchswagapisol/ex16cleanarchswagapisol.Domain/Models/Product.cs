﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ex16cleanarchswagapisol.Domain.Models
{
    public class Product
    {
        public int Id { get; set; }
        public string ProductName { get; set; }
        public string ProductDesc { get; set; }
        public string ProductISBN { get; set; }
        public string ProductPrice { get; set; }
        public int ProductRating { get; set; }
    }
}
