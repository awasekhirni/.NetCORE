﻿using ex16cleanarchswagapisol.Domain.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace ex16cleanarchswagapisol.Domain.Interfaces
{
    public interface IProductRepository
    {
        IEnumerable<Product> GetProducts();
    }
}
