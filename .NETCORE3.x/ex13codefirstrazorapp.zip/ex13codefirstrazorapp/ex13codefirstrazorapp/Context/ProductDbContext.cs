﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace ex13codefirstrazorapp.Context
{
    public class ProductDbContext:DbContext
    {
        public ProductDbContext(DbContextOptions options) : base(options) { }

        DbSet<Product> Products { get; set; }

        //populating the data into the database 

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Product>().HasData(
                new Product() { ProductId=123132,ProductName="Sony Xperia Z1",ProductDesc="Qualcomm 850 Processor",ProductPrice=48000,ProductQty=1,ProductRating=5} 
                );
        }
    }
}
