﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace ex13codefirstrazorapp.Migrations
{
    public partial class seeddata : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Products",
                columns: new[] { "ProductId", "ProductDesc", "ProductName", "ProductPrice", "ProductQty", "ProductRating" },
                values: new object[] { 123132, "Qualcomm 850 Processor", "Sony Xperia Z1", 48000, 1, 5 });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 123132);
        }
    }
}
