﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ex14codefirsteroptions.Context
{
    public class BookAuthors
    {
        [Key]
        public long BookId { get; set; }
        public long AuthorId { get; set; }

        //Many to Many relationship 
        //Intermediate table
        public virtual Author Author { get; set; }
        public virtual Book Book { get; set; }
    }
}
