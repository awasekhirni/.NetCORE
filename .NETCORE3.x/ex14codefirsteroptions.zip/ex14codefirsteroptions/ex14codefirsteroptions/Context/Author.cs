﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ex14codefirsteroptions.Context
{
    public class Author
    {

        public Author()
        {
            BookAuthors = new HashSet<BookAuthors>();
            
        }
        [Key]
        public long Id { get; set; }
        public string Name { get; set; }

        //Author has many contacts
        public virtual AuthorContact AuthorContact { get; set; }

        //Author can write many books
        public virtual ICollection<BookAuthors> BookAuthors { get; set; }
    }
}
