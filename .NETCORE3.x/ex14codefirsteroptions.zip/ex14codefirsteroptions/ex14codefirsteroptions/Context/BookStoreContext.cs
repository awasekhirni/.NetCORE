﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ex14codefirsteroptions.Context
{
    public class BookStoreContext:DbContext
    {

        public BookStoreContext(DbContextOptions options): base(options) { }

        DbSet<Author> Authors { get; set; }
        DbSet<AuthorContact> AuthorContacts { get; set; }
        DbSet<Book> Books { get; set; }
        DbSet<BookAuthors> BookAuthors { get; set; }
        DbSet<BookCategory> BookCategories { get; set; }
        DbSet<Publisher> Publishers { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<BookCategory>().HasData(
                new BookCategory() { CategoryName="Fiction",CategoryDesc="fiction series"},
                new BookCategory() { CategoryName = "Spirituality", CategoryDesc = "Spirituality series" },
                new BookCategory() { CategoryName = "Science", CategoryDesc = "Scientific series" },
                new BookCategory() { CategoryName = "Technical", CategoryDesc = "Technical series" },
                new BookCategory() { CategoryName = "Autobiography", CategoryDesc = "Autobiography series" }
                );

            modelBuilder.Entity<Publisher>().HasData(
                new Publisher() { Name= "Territorial Publishers"},
                new Publisher() { Name = "McGraw Hill Publications" },
                new Publisher() { Name = "Taylor Francis Publications" },
                new Publisher() { Name = "Aljazeera Publications" },
                new Publisher() { Name = "SycliQ Publications" }
                );

            modelBuilder.Entity<Author>().HasData(
                new Author() { Name="Syed Awase Khirni"},
                new Author() { Name="Syed Ameese Sadath"},
                new Author() { Name="Syed Rayyan Awais"},
                new Author() { Name="Syed Azeez Al Asaad"},
                new Author() { Name= "Shagufta Khan"}
                );

            modelBuilder.Entity<AuthorContact>().HasData(
                new AuthorContact() {  AuthorId=1, Mobile="111-222-3333", Address="111 victoria lane, toronto t1x 2z3,canada"},
                new AuthorContact() { AuthorId = 1, Mobile = "111-222-3333", Address = "111 victoria lane, toronto t1x 2z3,canada" },
                new AuthorContact() { AuthorId = 2, Mobile = "444-222-3333", Address = "333 jazeera lane, toronto z1x 2z3,canada" },
                new AuthorContact() { AuthorId = 3, Mobile = "666-222-3333", Address = "313 ali lane, toronto y1x 2z3,canada" },
                new AuthorContact() { AuthorId = 4, Mobile = "777-222-3333", Address = "786 owaisi rd, toronto q1x 2z3,canada" }
                );

           /* modelBuilder.Entity<Book>().HasData(
                new Book() { Title="Information Fallacy to protect users in data harvesting age", BookAuthors=,},
                new Book() { },
                new Book() { },
                new Book() { },
                new Book() { }
                );

            modelBuilder.Entity<BookAuthors>().HasData(
                new BookAuthors() { },
                new BookAuthors() { },
                new BookAuthors() { },
                new BookAuthors() { },
                new BookAuthors() { },
                new BookAuthors() { }
                );*/

        }
    }
}
