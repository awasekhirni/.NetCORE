﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ex15cleanarchappsol.Application.Interfaces;
using ex15cleanarchappsol.Application.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace ex15cleanarchappsol.WebUI.MVC.Controllers
{
    public class ProductController : Controller
    {
        //injecting service reference 
        private IProductService _productService;
        //constructor
        public ProductController(IProductService productService)
        {
            _productService = productService;
        }
       
        public IActionResult Index()
        {
            ProductViewModel model = _productService.GetProducts();
            return View(model);
        }
    }
}
