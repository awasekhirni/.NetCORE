﻿using ex15cleanarchappsol.Domain.Interfaces;
using ex15cleanarchappsol.Domain.Models;
using ex15cleanarchappsol.Infrastructure.Data.Context;
using System;
using System.Collections.Generic;
using System.Text;

namespace ex15cleanarchappsol.Infrastructure.Data.Repositories
{
    public class ProductRepository : IProductRepository
    {

        public StoreDbContext _context;

        public ProductRepository(StoreDbContext context)
        {
            _context = context;
        }

        IEnumerable<Product> IProductRepository.GetProducts()
        {
            return _context.Products;
        }
    }
}
