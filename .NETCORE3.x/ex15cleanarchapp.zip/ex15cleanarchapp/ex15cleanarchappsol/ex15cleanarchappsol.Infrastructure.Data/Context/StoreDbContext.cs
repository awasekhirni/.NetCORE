﻿using ex15cleanarchappsol.Domain.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace ex15cleanarchappsol.Infrastructure.Data.Context
{
    public class StoreDbContext : DbContext
    {
        public StoreDbContext(DbContextOptions options) : base(options)  {      
        }

        public DbSet<Product> Products { get; set; }
    }

}
