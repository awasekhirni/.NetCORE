﻿using ex15cleanarchappsol.Domain.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace ex15cleanarchappsol.Application.ViewModels
{
    public class ProductViewModel
    {
        public IEnumerable<Product> Products { get; set; }
    }
}
