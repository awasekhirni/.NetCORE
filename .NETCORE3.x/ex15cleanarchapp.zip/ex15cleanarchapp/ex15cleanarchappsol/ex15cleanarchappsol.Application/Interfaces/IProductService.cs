﻿using ex15cleanarchappsol.Application.ViewModels;
using System;
using System.Collections.Generic;
using System.Text;

namespace ex15cleanarchappsol.Application.Interfaces
{
    public interface IProductService
    {
        ProductViewModel GetProducts();
    }
}
