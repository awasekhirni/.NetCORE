﻿using ex15cleanarchappsol.Application.Interfaces;
using ex15cleanarchappsol.Application.ViewModels;
using ex15cleanarchappsol.Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace ex15cleanarchappsol.Application.Services
{
    public class ProductService : IProductService
    {
        //repository reference
        public IProductRepository _productRepo;

        //constructor
        public ProductService(IProductRepository productRepo)
        {
            _productRepo = productRepo;
        }
        public ProductViewModel GetProducts()
        {
            return new ProductViewModel()
            {
                Products = _productRepo.GetProducts()
            };
        }

    }
}
