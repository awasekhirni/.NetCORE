﻿using ex15cleanarchappsol.Domain.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace ex15cleanarchappsol.Domain.Interfaces
{
    public interface IProductRepository
    {
        IEnumerable<Product> GetProducts();
    }
}
