﻿using ex15cleanarchappsol.Application.Interfaces;
using ex15cleanarchappsol.Application.Services;
using ex15cleanarchappsol.Domain.Interfaces;
using ex15cleanarchappsol.Infrastructure.Data.Repositories;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;

namespace ex15cleanarchappsol.Infrastructure.Ioc
{
    public class DependencyContainer
    {

        public static void RegisterServices(IServiceCollection services)
        {
            //register application layer to scope 
            services.AddScoped<IProductService, ProductService>();

            //register the repository 
            // Domain=>Interfaces || Infrastructure.Data.Repository
            services.AddScoped<IProductRepository, ProductRepository>();
            
           
        }
    }
}
