﻿
insert into dbo.Products ( Name, Category, Color, UnitPrice, AvailableQuantity, CreatedDate) values ( 'Mercedes-Benz', 'G-Class', 'Crimson', 782173.94, 81, '2019-09-15 20:36:48');
insert into dbo.Products ( Name, Category, Color, UnitPrice, AvailableQuantity, CreatedDate) values ( 'Mercedes-Benz', '600SEC', 'Crimson', 470350.08, 72, '2020-08-30 22:23:30');
insert into dbo.Products ( Name, Category, Color, UnitPrice, AvailableQuantity, CreatedDate) values ( 'Lincoln', 'MKZ', 'Fuscia', 219253.08, 30, '2020-05-12 11:37:42');
insert into dbo.Products ( Name, Category, Color, UnitPrice, AvailableQuantity, CreatedDate) values ( 'Lexus', 'LS', 'Yellow', 349169.07, 62, '2020-03-26 08:54:13');
insert into dbo.Products ( Name, Category, Color, UnitPrice, AvailableQuantity, CreatedDate) values ( 'Ford', 'Explorer Sport Trac', 'Fuscia', 550463.57, 28, '2020-05-31 00:45:28');
insert into dbo.Products ( Name, Category, Color, UnitPrice, AvailableQuantity, CreatedDate) values ( 'Mercedes-Benz', '400E', 'Puce', 156313.98, 10, '2020-06-10 06:24:40');
insert into dbo.Products ( Name, Category, Color, UnitPrice, AvailableQuantity, CreatedDate) values ( 'GMC', 'Suburban 2500', 'Green', 548709.99, 70, '2020-03-16 12:00:26');
insert into dbo.Products ( Name, Category, Color, UnitPrice, AvailableQuantity, CreatedDate) values ( 'Mitsubishi', 'Outlander', 'Green', 901194.99, 92, '2019-12-21 16:43:13');
insert into dbo.Products ( Name, Category, Color, UnitPrice, AvailableQuantity, CreatedDate) values ( 'Toyota', 'Avalon', 'Turquoise', 529810.21, 67, '2019-11-04 21:54:04');
insert into dbo.Products ( Name, Category, Color, UnitPrice, AvailableQuantity, CreatedDate) values ( 'Chevrolet', 'Suburban 2500', 'Turquoise', 701365.7, 64, '2020-07-05 09:44:49');