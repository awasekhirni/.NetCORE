﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;

namespace ex11aspnetcoremiddlewareprj.Middlewares
{
    // You may need to install the Microsoft.AspNetCore.Http.Abstractions package into your project
    public class EnableFeatureMiddleware
    {
        private readonly RequestDelegate _next;

        public EnableFeatureMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task Invoke(HttpContext httpContext,IConfiguration config)
        {
            //step 1 
            if (httpContext.Request.Path.Value.Contains("/enable"))
            {
                var features = config.GetSection("EnableFeatures");
                var displayFeatures = features.GetChildren().Select(x => $"{x.Key}:{x.Value}");
                await httpContext.Response.WriteAsync(string.Join("\n", displayFeatures));
            }
            else
            {
                await _next(httpContext);
            }
        }
    }

    // Extension method used to add the middleware to the HTTP request pipeline.
    public static class EnableFeatureMiddlewareExtensions
    {
        public static IApplicationBuilder UseEnableFeatureMiddleware(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<EnableFeatureMiddleware>();
        }
    }
}
