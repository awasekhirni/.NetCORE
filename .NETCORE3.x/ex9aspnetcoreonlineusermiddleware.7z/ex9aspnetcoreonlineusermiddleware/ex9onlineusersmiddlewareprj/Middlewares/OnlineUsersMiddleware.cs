﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Caching.Memory;

namespace ex9onlineusersmiddlewareprj.Middlewares
{
    //step1- check for this dependencies version 3.x
       // You may need to install the Microsoft.AspNetCore.Http.Abstractions package into your project
    public class OnlineUsersMiddleware
    {
        private readonly RequestDelegate _next;

        //step2-- add the cookie and time
        private readonly string _cookieName;
        private readonly int _lastActivityMinutes = 20;

        private static readonly ConcurrentDictionary<string, bool> _allKeys = new ConcurrentDictionary<string, bool>();

        public OnlineUsersMiddleware(RequestDelegate next, string cookieName ="UserGuid", int lastActivityMinutes=20)
        {
            _next = next;
            _cookieName = cookieName;
            _lastActivityMinutes = lastActivityMinutes;
        }

        //step3 -- update the InvokeAsync method
        public Task InvokeAsync(HttpContext httpContext, IMemoryCache memoryCache)
        {
            if (httpContext.Request.Cookies.TryGetValue(
                _cookieName,
                out var userGuid) == false)
            {
                userGuid = Guid.NewGuid().ToString();
                httpContext.Response.Cookies.Append(_cookieName, userGuid,
                    new CookieOptions { HttpOnly = true, MaxAge = TimeSpan.FromDays(10) }
                    );
            }
            memoryCache.GetOrCreate(userGuid, cacheEntry => { 
            
                if(_allKeys.TryAdd(userGuid, true) == false)
                {
                    //if add key failed, set the expiration to the past
                    cacheEntry.AbsoluteExpiration = DateTimeOffset.MinValue;
                }
                else
                {
                    cacheEntry.SlidingExpiration = TimeSpan.FromSeconds(10);
                    cacheEntry.RegisterPostEvictionCallback(RemoveKeyWhenExpired);
                }
                return string.Empty;        
            });

            return _next(httpContext);
        }

        //step4- add the method to remove the key when expired
        private void RemoveKeyWhenExpired(object key, object value, EvictionReason reason, object state)
        {
            string strKey = (string)key;
            if (!_allKeys.TryRemove(strKey, out _))
                _allKeys.TryUpdate(strKey, false, true);
        }


        //step 5- get the no of online users count to render on the view pass this value to the controller
        public static int GetOnlineUsersCount() => _allKeys.Count(p => p.Value);
    }

    // Extension method used to add the middleware to the HTTP request pipeline.
    public static class OnlineUsersMiddlewareExtensions
    {
        public static IApplicationBuilder UseOnlineUsersMiddleware(this IApplicationBuilder builder, string cookieName="UserGuid", int lastActivityMinutes=20)
        {
            return builder.UseMiddleware<OnlineUsersMiddleware>(cookieName,lastActivityMinutes);
        }
    }
}
